package gps;

public class GPSInfo {
	private int hour;
	private int minute;
	private int second;
	
	private int day;
	private int month;
	private int year;
	
	private int jing;
	private char j;
	private int wei;
	private char w;
	
	
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		this.second = second;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getJing() {
		return jing;
	}
	public void setJing(int jing) {
		this.jing = jing;
	}
	public char getJ() {
		return j;
	}
	public void setJ(char j) {
		this.j = j;
	}
	public int getWei() {
		return wei;
	}
	public void setWei(int wei) {
		this.wei = wei;
	}
	public char getW() {
		return w;
	}
	public void setW(char w) {
		this.w = w;
	}
    
	
}
